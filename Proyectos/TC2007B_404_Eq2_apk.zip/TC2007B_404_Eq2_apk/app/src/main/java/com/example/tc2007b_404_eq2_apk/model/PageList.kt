package com.example.tc2007b_404_eq2_apk.model

class PageList : ArrayList<Page>()
