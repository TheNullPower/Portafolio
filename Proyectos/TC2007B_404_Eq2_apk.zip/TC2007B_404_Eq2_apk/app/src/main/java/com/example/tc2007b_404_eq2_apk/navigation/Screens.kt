package com.example.tc2007b_404_eq2_apk.navigation

enum class Screens {
    DetailsOSC
}