package com.example.tc2007b_404_eq2_apk.model

data class Star(
    val message: Boolean

)
