package com.example.tc2007b_404_eq2_apk.model

data class OrgResp(
    val name: String,
    val description: String,
    val _id: String,
    val email: String,
    val img: String,
    val linkb1: String,
    val linkb2: String,
    val linkb4: String
)
