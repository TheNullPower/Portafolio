package com.example.tc2007b_404_eq2_apk.model

data class Page(
    val titulo: String,
    val desc: String,
    val img: String,
    val orgId: String,
    val linkb1: String,
    val linkb2: String,
    val linkb4: String

)
