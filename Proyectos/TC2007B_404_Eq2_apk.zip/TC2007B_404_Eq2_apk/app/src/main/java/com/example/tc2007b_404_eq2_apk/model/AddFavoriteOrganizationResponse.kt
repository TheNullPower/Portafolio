package com.example.navdrawer.model

data class AddFavoriteOrganizationResponse(
    val message: String
)
