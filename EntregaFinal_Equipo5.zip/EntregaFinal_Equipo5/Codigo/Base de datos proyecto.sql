--create database reto

use reto

CREATE TABLE Clientes (
    IdCliente FLOAT PRIMARY KEY,
    Pais VARCHAR(255),
    Region VARCHAR(255),
    Municipio VARCHAR(255),
    CEDI VARCHAR(255),
    Colonia VARCHAR(255),
	Ciudad varchar(225),
	Estado varchar(225),
    CP VARCHAR(10),
    Fname VARCHAR(255),
    Lname VARCHAR(255),
    NumINE VARCHAR(18),
    Celular VARCHAR(20),
    Direccion VARCHAR(255),
);

insert into Clientes
values(58293949592, 'M�xico', 'Noreste', 'Monterrey', 'Guadalupe', 'Buenos Aires', 'Monterrey', 'Nuevo Le�n', 64800, 'Antonia', 'L�pez', 1836577170, 8111753034, 'Xochimilco 3B'),
(58647327483, 'M�xico', 'Noreste', 'Monterrey', 'Guadalupe', 'Jardines de Altavista', 'Monterrey', 'Nuevo Le�n', 64846, 'Mar�a del Carmen', 'Garza', 2738403029, 8128384929, 'Junco de la Vega 726'),
(58273724957, 'M�xico', 'Noreste', 'Monterrey', 'Guadalupe', 'Caracol', 'Monterrey', 'Nuevo Le�n', 64810, 'Andr�s', 'Calvillo', 5628383829, 8114883312, 'Juventino Rosas 88'),
(56134828483, 'M�xico', 'Noreste', 'Monterrey', 'Guadalupe', 'Buenos Aires', 'Monterrey', 'Nuevo Le�n', 64800, 'Juli�n', 'Ram�rez', 2902838370, 8193848223, 'Chapultepec 93'),
(57283648211, 'M�xico', 'Noreste', 'Monterrey', 'Guadalupe', 'Tecnol�gico', 'Monterrey', 'Nuevo Le�n', 64849, 'Liliana', 'Guerra', 1039747282, 8151712348, 'Ingenieros 571'),
(59273849291, 'M�xico', 'Noreste', 'Monterrey', 'Guadalupe', 'Cerro de la Silla', 'Monterrey', 'Nuevo Le�n', 64810, 'Aliana', 'Gonz�lez', 1982837223, 8111729402, 'Helechos 222'),
(55929038482, 'M�xico', 'Noreste', 'Monterrey', 'Guadalupe', 'Roma', 'Monterrey', 'Nuevo Le�n', 64700, 'Pedro', 'Rodr�guez', 4737822832, 8111229228, 'Rio Guadalquivir 17'),
(58273774822, 'M�xico', 'Noreste', 'Monterrey', 'Guadalupe', 'Residencial La Espa�ola', 'Monterrey', 'Nuevo Le�n', 64820, 'Ana Karen', 'Guaita', 2030338748, 8172838321, 'Tucum�n 81'),
(56220838292, 'M�xico', 'Noreste', 'Monterrey', 'Guadalupe', 'Narvarte', 'Monterrey', 'Nuevo Le�n', 64830, 'Daniel', 'Garza', 2030303020, 8187283828, 'Kiel 1727'),
(56728192731, 'M�xico', 'Noreste', 'Monterrey', 'Guadalupe', 'Caracol', 'Monterrey', 'Nuevo Le�n', 64810, 'Ermenegildo', 'Rodarte', 3349039393, 8112848482, 'Jos� Mar�a Morelos 451')

create table Usuarios(
	IdUsuario int primary key identity(9010,1),
	username varchar(250),
	contrase�a varchar(250),
	perfil varchar(50)
)

insert into Usuarios
values('juanmercedes@arcacontal.com', '290594837', 'Desarrollador'),
('salvadordolis@arcacontal.com', '2984837904', 'Desarrollador'),
('franciscogarcia@arcacontal.com', 'fg6750927', 'Desarrollador'),
('gabriellopez@arcacontal.com', '6758478209', 'Desarrollador'),
('adrianperez@arcacontal.com', 'aa4537p738', 'Desarrollador'),
('davidgarza@arcacontal.com', '6283849827', 'Chofer'),
('andreslopez@arcacontal.com', 'al6838492098', 'Chofer'),
('carlosramirez@arcacontal.com', '69848302983', 'Admin'),
('santiagovillareal@arcacontal.com', '8927638489723', 'Admin')

CREATE TABLE Desarrollador (
  IdEmpleado int PRIMARY KEY,
  FnameEmpleado varchar(255),
  LnameEmpleado varchar(255),
  CelularEmpleado varchar(20),
  Region varchar(255),
  CEDI varchar(255),
  IdUsuario int,
  foreign key (IdUsuario) references Usuarios(IdUsuario)
);

insert into Desarrollador
values(326372, 'Juan', 'Mercedes', '8117263540', 'Noreste', 'Guadalupe', 9010),
(367539, 'Salvador', 'Sol�s', '8116254929', 'Noreste', 'Guadalupe', 9011),
(336840, 'Francisco', 'Garcia', '8115789087', 'Noreste', 'Guadalupe', 9012),
(357866, 'Gabriel', 'Lopez', '8144678590', 'Noreste', 'Guadalupe', 9013),
(372309, 'Adrian', 'Perez', '8134560933', 'Noreste', 'Guadalupe', 9014)

CREATE TABLE Chofer (
  IdEmpleado int PRIMARY KEY,
  FnameEmpleado varchar(255),
  LnameEmpleado varchar(255),
  CelularEmpleado varchar(20),
  Region varchar(255),
  CEDI varchar(255),
  IdUsuario int,
  foreign key (IdUsuario) references Usuarios(IdUsuario)
);

insert into Chofer
values(236980, 'David', 'Garza', '8120395088','Noreste', 'Guadalupe', 9015),
(217099, 'Andres', 'Lopez', '8149309867', 'Noreste', 'Guadalupe', 9016)

CREATE TABLE Admin (
  IdEmpleado int PRIMARY KEY,
  FnameEmpleado varchar(255),
  LnameEmpleado varchar(255),
  CelularEmpleado varchar(20),
  Region varchar(255),
  CEDI varchar(255),
  IdUsuario int,
  foreign key (IdUsuario) references Usuarios(IdUsuario)
);

insert into Admin
values(406789, 'Carlos', 'Ramirez', '8120894567','Noreste', 'Guadalupe', 9017),
(450219, 'Santiago', 'Villareal', '8190467899', 'Noreste', 'Guadalupe', 9018)

CREATE TABLE Cooler (
    IdCooler INT PRIMARY KEY identity(3010,5),
    ModeloCooler VARCHAR(255),
    Marca VARCHAR(255),
    Identificador VARCHAR(255),
    NumPuertas INT,
    PotencialVentasMensual FLOAT,
    SizeCliente VARCHAR(255),
    TypeDoor VARCHAR(255),
    CapacidadBottle INT,
    LlenadoPuerta INT,
    IngresoMensualCliente FLOAT,
    GananciaMensualCliente FLOAT,
    ConsumoEnergeticoMensual FLOAT,
    ConsumoEnergeticoDinero FLOAT,
	AnchoEnCm INT,
	AlturaEnCm INT,
	ProfundidadEnCm INT,
	ImagenCooler varchar(250)
);

insert into Cooler
values('CFX-19', 'Criotec', 'CRIOTEC-CFX19-P', 1, 20, 'Peque�o', 'Coca-Cola', 322, 2, 11592.00, 3220.00, 2.49, 1837.00, 54, 82, 52, ''),
('CFX-42', 'Criotec', 'CRIOTEC-CFX42_P', 2, 40, 'Peque�o', 'Coca-Cola', 720, 2, 25920.00, 7200.00, 4.25, 3674.00, 60, 70, 55, ''),
('CFX-19', 'Criotec', 'CRIOTEC-CFX19-M', 1, 40, 'Mediano', 'Coca-Cola', 322, 4, 23184.00, 6440.00, 2.49, 1837.00, 54, 82, 52, ''),
('CFX-42', 'Criotec', 'CRIOTEC-CFX42-M', 2, 80, 'Mediano', 'Coca-Cola', 720, 4, 51840.00, 14400.00, 4.25, 3674.00, 60, 70, 55, ''),
('CFX-64', 'Criotec', 'CRIOTEC-CFX64-M', 3, 105, 'Mediano', 'Coca-Cola', 945, 5, 85050.00, 23625.00, 6.82, 4899.00, 58, 140, 63, ''),
('CFX-19', 'Criotec', 'CRIOTEC-CFX19-G', 1, 80, 'Grande', 'Coca-Cola', 322, 8, 46368.00, 12880.00, 2.49, 1837.00, 54, 82, 52, ''),
('CFX-42', 'Criotec', 'CRIOTEC-CFX42-G', 2, 160, 'Grande', 'Coca-Cola', 720, 6, 77760.00, 21600.00, 4.25, 3674.00, 60, 70, 55, ''),
('CFX-64', 'Criotec', 'CRIOTEC-CFX64-G', 3, 210, 'Grande', 'Coca-Cola', 945, 6, 102060.00, 28350.00, 6.82, 4899.00, 58, 140, 63, '')

CREATE TABLE Negocio (
    IdNegocio INT PRIMARY KEY identity(1010,5),
	NombreNegocio VARCHAR(255),
    NumPuertas INT,
    NumCoolers INT,
    Pais VARCHAR(255),
    Region VARCHAR(255),
    Municipio VARCHAR(255),
    CEDI VARCHAR(255),
    NameApoderado VARCHAR(255),
    NumINE VARCHAR(18),
    Canal VARCHAR(255),
    Giro VARCHAR(255),
    CelularNegocio VARCHAR(20),
    ColoniaNegocio VARCHAR(255),
	CiudadNegocio varchar(225),
	EstadoNegocio varchar(225),
    CPnegocio VARCHAR(10),
    Size VARCHAR(255),
    VentaMensual FLOAT,
    Comodato INT,
    IdComodato INT,
    IdCliente FLOAT,
    DireccionNegocio VARCHAR(255),
	AnchoPuertaEnCm float,
	AlturaPuertaEnCm float,
	FechaRegistro date,
    FOREIGN KEY (IdCliente) REFERENCES Clientes(IdCliente),
);

insert into Negocio
values('Abarrotes To�ita', 1, 1, 'M�xico', 'Noreste', 'Monterrey', 'Guadalupe', 'Antonia L�pez Villarreal', '1836577170', 'Tradicional', 'Abarrotes', '8111753034', 'Buenos Aires', 'Monterrey', 'Nuevo Le�n', 64800, 'Peque�o', '', 1, 2640384, 58293949592, 'Xochimilco 3B', 85, 210, '5-23-2023'),
('Tiendita Las Rosas', 3, 3, 'M�xico', 'Noreste', 'Monterrey', 'Guadalupe', 'Mar�a del Carmen Garza Rosas', '2738403029', 'Tradicional', 'Tienda de Conveniencia', '8128384929', 'Jardines de Altavista', 'Monterrey', 'Nuevo Le�n', 64846, 'Mediano', '', 1, 3748392, 58647327483, 'Junco de la Vega 726', 85, 210, '2-17-2023'),
('Dep�sito Caracol', 0, 0, 'M�xico', 'Noreste', 'Monterrey', 'Guadalupe', 'Andr�s Calvillo Bernal', '5628383829', 'Tradicional', 'Tienda de Conveniencia', '8114883312', 'Caracol', 'Monterrey', 'Nuevo Le�n', 64810, 'Peque�o', '', 0, 2349392, 58273724957, 'Juventino Rosas 88', 83, 203, '1-5-2023'),
('Abarrotes Ram�rez', 3, 5, 'M�xico', 'Noreste', 'Monterrey', 'Guadalupe', 'Juli�n Ram�rez Gonz�lez', '2902838370', 'Tradicional', 'Abarrotes', '8193848223', 'Buenos Aires', 'Monterrey', 'Nuevo Le�n', 64800, 'Grande', '', 1, 2939483, 56134828483, 'Chapultepec 93', 100, 230, '3-28-2003'),
('Abarrotes Lily', 2, 3, 'M�xico', 'Noreste', 'Monterrey', 'Guadalupe', 'Liliana Guerra Pa�z', '1039747282', 'Tradicional', 'Abarrotes', '8151712348', 'Tecnol�gico', 'Monterrey', 'Nuevo Le�n', 64849, 'Grande', '', 1, 3327683, 57283648211, 'Ingenieros 571', 150, 290, '4-20-2023'),
('Super Ally', 1, 3, 'M�xico', 'Noreste', 'Monterrey', 'Guadalupe', 'Aliana Gonz�lez Jim�nez', '1982837223', 'Tradicional', 'Mini s�per independiente', '8111729402', 'Cerro de la Silla', 'Monterrey', 'Nuevo Le�n', 64810, 'Mediano', '', 1, 3672828, 59273849291, 'Helechos 222', 83, 203, '4-13-2023'),
('Tienda Dos Bocas', 1, 2, 'M�xico', 'Noreste', 'Monterrey', 'Guadalupe', 'Pedro Rodr�guez Barrera', '4737822832', 'Tradicional', 'Tienda de Conveniencia', '8111229228', 'Roma', 'Monterrey', 'Nuevo Le�n', 64700, 'Mediano', '', 1, 2837620, 55929038482, 'Rio Guadalquivir 17', 83, 203, '1-19-2023'),
('Super Tec', 0, 0, 'M�xico', 'Noreste', 'Monterrey', 'Guadalupe', 'Ana Karen Guaita Barreda', '2030338748', 'Tradicional', 'Mini s�per independiente', '8172838321', 'Residencial La Espa�ola', 'Monterrey', 'Nuevo Le�n', 64820, 'Peque�o', '', 0, 2837468, 58273774822, 'Tucum�n 81', 85, 210, '5-4-2023'),
('Abarrotes Dany', 2, 3, 'M�xico', 'Noreste', 'Monterrey', 'Guadalupe', 'Daniel Garza Gonz�lez', '2030303020', 'Tradicional', 'Abarrotes', '8187283828', 'Narvarte', 'Monterrey', 'Nuevo Le�n', 64830, 'Mediano', '', 1, 2934482, 56220838292, 'Kiel 1727', 85, 210, '5-2-2023'),
('Dep�sito', 2, 5, 'M�xico', 'Noreste', 'Monterrey', 'Guadalupe', 'Ermenegildo Rodarte Arduen', '3349039393', 'Tradicional', 'Abarrotes', '8112848482', 'Caracol', 'Monterrey', 'Nuevo Le�n', 64810, 'Grande', '', 1, 3239493, 56728192731, 'Jos� Mar�a Morelos 451', 140, 270, '2-15-2023')

/*create table CoolerNegocio(
	IdCN int primary key,
	IdNegocio int,
	IdCooler int null,
	foreign key(IdNegocio) references Negocio(IdNegocio),
	foreign key(IdCooler) references Cooler(IdCooler)
);

insert into CoolerNegocio
values(1, 1010, 3010),
(2, 1015, 3020),
(3, 1015, 3020),
(4, 1015, 3020),
(5, 1020, null),
(6, 1025, 3040),
(7, 1025, 3040),
(8, 1025, 3035),
(9, 1030, 3035),
(10, 1030, 3040),
(11, 1035, 3030),
(12, 1040, 3025),
(13, 1045, null),
(14, 1050, 3025),
(15, 1050, 3020),
(16, 1055, 3045),
(17, 1055, 3040)*/

CREATE TABLE Visita (
  IdVisita int PRIMARY KEY identity(2010,1),
  IdEmpleado int,
  FechaVisita date,
  IdNegocio int,
  FOREIGN KEY (IdNegocio) REFERENCES Negocio(IdNegocio),
  FOREIGN KEY (IdEmpleado) REFERENCES Desarrollador(IdEmpleado)
);

insert into Visita
values(326372, '2-14-2023', 1010),
(326372, '2-19-2023', 1040),
(326372, '2-20-2023', 1020),
(367539, '2-15-2023', 1055),
(367539, '2-17-2023', 1015),
(336840, '3-28-2003', 1025),
(357866, '4-20-2023', 1030),
(372309, '4-13-2023', 1035)

create table CheckList(
	IdCheckList int primary key identity(6005,1),
	Entrada int,
	PosicionCooler int,
	MovimientosExtras int,
	PersonasExtra int,
	Horario int, --(1(8am-12pm),2(12pm a 4pm),3(4pm a 8pm))
	Comentarios text
);

insert into CheckList
values(1, 1, 0, 0, 1, 'Sin comentarios'),
(1, 1, 0, 0, 3, 'Sin comentarios'),
(1, 1, 1, 1, 3, 'Se ocupa movimientos de estantes'),
(1, 1, 1, 2, 2, 'Se ocupa varios movimientos de estantes'),
(1, 1, 0, 0, 2, 'Sin comentarios'),
(1, 1, 1, 1, 1, 'La posicion del equipo de frio es muy justa'),
(1, 1, 0, 0, 1, 'Sin comentarios'),
(1, 1, 1, 2, 2, 'Es necesario hacer movimientos de estantes')

CREATE TABLE Solicitud (
  IdSolicitud int PRIMARY KEY identity(4010,1), 
  FechaSolicitud date,
  Pais varchar(225),
  Region varchar(225),
  CEDI varchar(225),
  IdDesarrollador int,
  IdCliente float,
  IdNegocio int,
  IdChofer int,
  IdAdmin int,
  IdVisita int, 
  IdCheckList int, 
  StatusSolicitud varchar(50)
  FOREIGN KEY (IdChofer) REFERENCES Chofer(IdEmpleado),
  FOREIGN KEY (IdDesarrollador) REFERENCES Desarrollador(IdEmpleado),
  FOREIGN KEY (IdAdmin) REFERENCES Admin(IdEmpleado),
  FOREIGN KEY (IdVisita) REFERENCES Visita(IdVisita),
  foreign key (IdCheckList) references CheckList(IdCheckList)
);

insert into Solicitud
values('2-14-2023', 'M�xico', 'Noreste', 'Guadalupe', 326372, 58293949592, 1010, 236980, 406789, 2010, 6005, 'Completada'), --Peque�o
('2-19-2023', 'M�xico', 'Noreste', 'Guadalupe', 326372, 55929038482, 1040, 236980, 406789, 2011, 6006, 'Pendiente'), --Mediano
('2-20-2023', 'M�xico', 'Noreste', 'Guadalupe', 326372, 58273724957, 1020, 236980, 406789, 2012, 6007, 'Aceptada'), --Peque�o
('2-15-2023', 'M�xico', 'Noreste', 'Guadalupe', 367539, 56728192731, 1055, 217099, 450219, 2013, 6008, 'Completada'), --Grande
('2-17-2023', 'M�xico', 'Noreste', 'Guadalupe', 367539, 58647327483, 1015, 217099, 450219, 2014, 6009, 'Cancelada'), --Mediano
('3-28-2023', 'M�xico', 'Noreste', 'Guadalupe', 336840, 56134828483, 1025, 217099, 406789, 2015, 6010, 'Aceptada'), --Grande
('5-28-2023', 'M�xico', 'Noreste', 'Guadalupe', 357866, 57283648211, 1030, 236980, 450219, 2016, 6011, 'Cancelada'), -- Grande
('4-13-2023', 'M�xico', 'Noreste', 'Guadalupe', 372309, 59273849291, 1035, 236980, 450219, 2017, 6012, 'Pendiente') --Mediano

create table CoolerSolicitado(
	IdCS int primary key identity(1,1),
	IdSolicitud int,
	IdCooler int,
	FechaEntrega date,
	StatusCooler varchar(50),
	foreign key (IdSolicitud) references Solicitud(IdSolicitud),
	foreign key (IdCooler) references Cooler(IdCooler)
);

insert into CoolerSolicitado
values(4010, 3010, '3-1-2023', 'Entregado'),
(4010, 3015, '3-1-2023', 'Entregado'),
(4011, 3025, '2-27-2023', 'Entregado'),
(4012, 3010, '3-1-2023', 'Pendiente'),
(4013, 3045, '3-2-2023', 'Entregado'),
(4013, 3040, '3-4-2023', 'Entregado'),
(4014, 3030,'2-27-2023', 'Cancelado'),
(4015, 3035,'4-1-2023', 'Pendiente'),
(4016, 3040,'6-4-2023', 'Cancelado'),
(4017, 3020,'5-2-2023', 'Pendiente')

create table EvidenciaDesarrollador(
	IdEvD int primary key identity(7010,1),
	IdSolicitud int,
	IdEmpleado int,
	EvidenciaAR varchar(5000),
	FechaEvidenciaDesarrollador date,
	foreign key (IdSolicitud) references Solicitud(IdSolicitud),
	foreign key (IdEmpleado) references Desarrollador(IdEmpleado)
);

insert into EvidenciaDesarrollador
values (4010, 326372, '', '2-14-2023'),
(4010, 326372, '', '2-14-2023'),
(4011, 326372, '', '2-19-2023'),
(4012, 326372, '', '2-20-2023'),
(4013, 367539, '', '2-15-2023'),
(4013, 367539, '', '2-15-2023'),
(4014, 367539, '', '2-17-2023'),
(4015, 336840, '', '3-28-2023'),
(4016, 357866, '', '5-28-2023'),
(4017, 372309, '', '4-13-2023')

create table EvidenciaChofer(
	idEvC int identity(8010,1),
	IdSolicitud int,
	IdChofer int,
	EvidenciaIRL varchar(5000) null,
	FechaEvidenciaChofer date null,
	foreign key (IdSolicitud) references Solicitud(IdSolicitud),
	foreign key (IdChofer) references Chofer(IdEmpleado)
);

insert into EvidenciaChofer
values (4010, 236980, '', '3-1-2023'),
(4010, 236980, '', '3-1-2023'),
(4013, 217099, '', '3-4-2023'),
(4013, 217099, '', '3-2-2023'),
(4017, 236980, '', '6-4-2023')
